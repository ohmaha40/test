"use strict";

console.log("Hallo Dennis!");
console.log("Hallo Ruben!");
console.log("Wie geht es dir?");
console.log("Mir geht es gut!");